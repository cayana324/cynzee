/* ===== KONFIGURASI: ganti di sini ===== */
const CONFIG = {
  name: "cynzee",
  photo: "images/profile.jpg",       
  background: "images/bg.jpg",     
  links: [
    { id:"instagram", label:"Instagram", url:"https://www.instagram.com/__cxx.3yx/" },
    { id:"tiktok",    label:"TikTok",    url:"https://www.tiktok.com/@cynze_" },
    { id:"whatsapp",  label:"WhatsApp",  url:"https://wa.me/6287866077131" },
    { id:"line",      label:"LINE",      url:"https://line.me/ti/p/I5DC1bt6qA" },
    { id:"email",     label:"Email",     url:"https://mail.google.com/mail/?view=cm&fs=1&to=cayana0411@gmail.com&su=Halo%20Cynzee" }
  ]
};
/* ===== Ikon ===== */
const A='fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
const ICONS={
 instagram:`<svg class="ic" viewBox="0 0 24 24" ${A}><rect x="3" y="3" width="18" height="18" rx="5.5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.3" cy="6.7" r=".9" fill="currentColor"/></svg>`,
 tiktok:`<svg class="ic" viewBox="0 0 24 24" ${A}><path d="M15 3v11.2a4.2 4.2 0 1 1-4.2-4.2"/><path d="M15 3c.3 2.6 2.1 4.4 4.8 4.6"/></svg>`,
 whatsapp:`<svg class="ic" viewBox="0 0 24 24" ${A}><path d="M3.2 20.8l1.5-4.7A8.8 8.8 0 1 1 8 19.3l-4.8 1.5z"/><path d="M9 7.8c-.4 3.6 3.3 7.4 7.2 7l.9-1.4-2.2-1.1-1 .9c-1-.4-2-1.4-2.4-2.4l.9-1-1-2.2L9 7.8z"/></svg>`,
 line:`<svg class="ic" viewBox="0 0 24 24"><path d="M12 2C6.5 2 2.5 5.6 2.5 10c0 3.8 3 7 7.3 7.8-.1 1.3-.7 2.6-1.6 3.6 2.8-.4 5.3-2.4 6.6-3.9 3.9-1 6.7-3.9 6.7-7.5C21.5 5.6 17.5 2 12 2z" fill="currentColor"/><text x="12" y="12.3" font-family="Arial,sans-serif" font-weight="800" font-size="5.6" fill="#fff8f3" text-anchor="middle">LINE</text></svg>`,
 email:`<svg class="ic" viewBox="0 0 24 24" ${A}><rect x="2.5" y="4.5" width="19" height="15" rx="2.5"/><path d="M3 6.5l9 7 9-7"/></svg>`
};
const STAR='<svg class="s" viewBox="0 0 24 24" fill="#f08a96"><path d="M12 0c1 7 5 11 12 12-7 1-11 5-12 12-1-7-5-11-12-12C7 11 11 7 12 0z"/></svg>';
/* ===== Render ===== */
document.getElementById('nm').textContent=CONFIG.name;
const ph=document.getElementById('ph');
ph.src=CONFIG.photo;
ph.onerror=()=>{ph.onerror=null;ph.src='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#ffe3d6"/><circle cx="50" cy="38" r="16" fill="#f2a0a8"/><path d="M18 90c4-22 20-30 32-30s28 8 32 30z" fill="#f2a0a8"/></svg>')};
try{document.getElementById('bg').style.backgroundImage=`url("${CONFIG.background}")`}catch(e){}
const nav=document.getElementById('links');
CONFIG.links.forEach((l,i)=>{
  const a=document.createElement('a');
  a.className='btn glass';a.href=l.url;a.style.setProperty('--i',i);
  a.setAttribute('aria-label',l.label);
  if(!l.url.startsWith('mailto:')){a.target='_blank';a.rel='noopener noreferrer'}
  a.innerHTML=STAR+`<span class="t">${l.label}</span>`+(ICONS[l.id]||'');
  nav.appendChild(a);
});
/* Daun maple jatuh */
const box=document.getElementById('leaves');
for(let i=0;i<14;i++){
  const s=document.createElement('span');s.className='leaf';s.textContent='🍁';
  s.style.left=(Math.random()*100)+'%';
  s.style.fontSize=(14+Math.random()*16)+'px';
  s.style.setProperty('--dx',(Math.random()*80-40)+'px');
  s.style.animationDuration=(14+Math.random()*12)+'s';
  s.style.animationDelay=(-Math.random()*24)+'s';
  box.appendChild(s);
}
